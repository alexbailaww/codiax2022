def askQuestion(char1, char2, prompt):
    response = openai.Completion.create(
    model="text-davinci-002",
    prompt=prompt + char1 + ":",
    temperature=0.7,
    max_tokens=1357,
    top_p=1,
    frequency_penalty=0,
    presence_penalty=0,
    stop=[char1, char2]
    ).choices[0].text.replace("\n", "")

    
    return response