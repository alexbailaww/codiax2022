def getKey():
    key = open("key.txt", "r").read()
    return key