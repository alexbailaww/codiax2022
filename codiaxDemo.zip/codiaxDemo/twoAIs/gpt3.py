import os
import openai
import re

from getKey import getKey
from highlightText import highlightText

key1 = "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"
key2 = "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"
maxRetries = 5

# highlightText("This is a debate simulator with celebrities. Choose the celebrities you want to debate and the subject.", "green")
# char1 = input("Celebrity 1: ")
# char2 = input("Celebrity 2: ")
# topic = input("Topic: ")

char1 = "Snoop Dogg"
char2 = "Donald Trump"
topic = "legalizing weed"

highlightText("{} vs {} about {}\n".format(char1, char2, topic), "cyan")

initialPrompt = "You are {}. You are debating with {} about {}, in front of 10000 people. You feel strongly about your point of view and you totally dominate your opponent by giving snappy come-backs in {}'s style.\n"
prompt1 = initialPrompt.format(char1, char2, topic, char1)

stops = [w + ":" for w in re.split(r"\W", char1)][:-1] + [char1 + ":"] + [w + ":" for w in re.split(r"\W", char2)][:-1] + [char2 + ":"]
#stops = ["Snoop Dogg:", "Snoop:", "Donald Trump:", "Trump:"]
prompt2 = initialPrompt.format(char1, char2, topic, char1)
help1 = "{}:".format(char1)
help2 = "{}:".format(char2)

replies = []
i = 0
while i < 5:
    openai.api_key = key1
    question = ""
    retries = 0
    while (not question or question in replies) and retries<maxRetries:
        jiggleConversation = ""
        if retries > maxRetries/2:
            jiggleConversation = "(ends this debate and changes the topic)"
        if not replies:
            jiggleConversation = "(starts the debate)"
        question = openai.Completion.create(
            model="text-davinci-002",
            prompt=prompt1 + help1 + jiggleConversation,
            temperature=1,
            max_tokens=64,
            top_p=1,
            frequency_penalty=2,
            presence_penalty=1,
            stop=stops
            ).choices[0].text.replace("\n", "")
        retries += 1

    if retries >= maxRetries:
        question = "I don't know what else to say"
    replies.append(question)
    prompt1 = prompt1 + help1 + question + "\n"
    prompt2 = prompt2 + char1 + ":" + question + "\n"
    

    openai.api_key = key2

    answer = ""
    retries = 0
    while (not answer or answer in replies) and retries<maxRetries:
        jiggleConversation = ""
        if retries > maxRetries/2:
            jiggleConversation = "(ends this debate and changes the topic)"
        answer = openai.Completion.create(
            model="text-davinci-002",
            prompt=prompt2 + help2 + jiggleConversation,
            temperature=1,
            max_tokens=64,
            top_p=1,
            frequency_penalty=2,
            presence_penalty=1,
            stop=stops
            ).choices[0].text.replace("\n", "")
        retries += 1      

    if retries >= maxRetries:
        answer = "I don't know what else to say"

    replies.append(answer)
    prompt2 = prompt2 + help2 + answer + "\n"
    prompt1 = prompt1 + char2 + ":" + answer + "\n"

    highlightText(char1, "yellow")
    print(question)
    highlightText(char2, "red")
    print(answer)

    i += 1

# print("\nfinal prompt\n" + prompt1)

