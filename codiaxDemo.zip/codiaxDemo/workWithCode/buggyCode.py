#Buggy code
"""import random
a = random.randint(1,12)
b = random.randint(1,12)
for i in range(10):
    question 2= "What is "+str(a)+" x "+str(b)+"? "
    answer =@ input(question)
    if answer == str(a*b):
        print 2 ("Well done!")
    else:
        print("No.")
"""

#Debugged code:

import random
a = random.randint(1,12)
b = random.randint(1,12)
for i in range(10):
    question = "What is "+str(a)+" x "+str(b)+"? "
    answer = input(question)
    if answer == str(a*b):
        print ("Well done!")
    else:
        print("No.")

